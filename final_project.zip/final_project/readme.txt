Group 7
Project: Digital Certified Mail
Group member: Duanwei Zhang(500824903,section 03), Yu Zhang(500641786,section 01),
 Haoren Zhou(500702305, section 02), Lai shan Nixon Mark(500844772, section 03)
